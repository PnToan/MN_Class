# MN Jagua-Rust Nesting Engine 0.1.0

Engine độc lập cho chức năng nesting của MN_Class_Gcode.

- `jagua-rs` 0.7.2: collision detection và kiểm tra feasibility.
- Optimizer MN riêng: portfolio constructive, front-load, sheet evacuation và compact.
- Giao thức JSON v2; không dùng Node.js, `worker.js`, `clipper.js` hay `calculate_nfp.node`.
- Mục tiêu lexicographic: số sheet → chi tiết hai mặt ở sheet đầu → hiệu suất sheet đầu → compact area → sliver/dead zones.
