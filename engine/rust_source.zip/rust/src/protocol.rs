use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};
use std::path::PathBuf;

#[derive(Debug, Clone)]
pub struct Cli {
    pub job: PathBuf,
    pub result: PathBuf,
    pub progress: PathBuf,
    pub preview: PathBuf,
    pub svg: PathBuf,
    pub cancel: PathBuf,
    pub workers: usize,
}

impl Cli {
    pub fn parse() -> anyhow::Result<Self> {
        let mut args = std::env::args().skip(1);
        let mut values = std::collections::HashMap::<String, String>::new();
        while let Some(flag) = args.next() {
            let value = args.next().ok_or_else(|| anyhow::anyhow!("Thiếu giá trị cho {flag}"))?;
            values.insert(flag, value);
        }
        let path = |name: &str| -> anyhow::Result<PathBuf> {
            values.get(name).map(PathBuf::from).ok_or_else(|| anyhow::anyhow!("Thiếu tham số {name}"))
        };
        let workers = values.get("--workers").and_then(|v| v.parse().ok()).unwrap_or(1).clamp(1, 32);
        Ok(Self {
            job: path("--job")?, result: path("--result")?, progress: path("--progress")?,
            preview: path("--preview")?, svg: path("--svg")?, cancel: path("--cancel")?, workers,
        })
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct Job {
    pub protocol_version: u32,
    #[serde(default)] pub source: String,
    #[serde(default)] pub optimization_attempts: usize,
    pub materials: Vec<MaterialJob>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct MaterialJob {
    pub key: String,
    pub material: String,
    pub thickness: f64,
    #[serde(default)] pub group_index: usize,
    pub configuration: Config,
    #[serde(default)] pub original_part_count: usize,
    pub parts: Vec<Value>,
}

#[derive(Debug, Clone, Deserialize)]
pub struct Config {
    pub board_width: f64,
    pub board_height: f64,
    #[serde(default)] pub edge_margin: f64,
    #[serde(default)] pub cut_gap: f64,
    #[serde(default = "default_rotation_divisions")] pub rotation_divisions: usize,
    #[serde(default)] pub sheet_in_sheet: bool,
    #[serde(default)] pub priority_zone_nesting: bool,
    #[serde(default)] pub optimize_flip_face: bool,
    #[serde(default)] pub compact_directions: Vec<String>,
    #[serde(default = "default_time_ms")] pub max_nesting_time_ms: u64,
}
fn default_rotation_divisions() -> usize { 1 }
fn default_time_ms() -> u64 { 40_000 }

#[derive(Debug, Clone)]
pub struct Part {
    pub raw: Map<String, Value>,
    pub entity_id: String,
    pub order: usize,
    pub contour: Vec<Point>,
    pub holes: Vec<Vec<Point>>,
    pub area: f64,
    pub width: f64,
    pub height: f64,
    pub base_rotation: f64,
    pub two_sided: bool,
    pub special_shape: bool,
}

pub type Point = [f64; 2];

impl Part {
    pub fn from_value(value: Value) -> anyhow::Result<Self> {
        let raw = value.as_object().cloned().ok_or_else(|| anyhow::anyhow!("Part không phải object JSON"))?;
        let entity_id = raw.get("entity_id").and_then(Value::as_str).unwrap_or_default().to_owned();
        if entity_id.is_empty() { anyhow::bail!("Part thiếu entity_id"); }
        let order = raw.get("order").and_then(Value::as_u64).unwrap_or(0) as usize;
        let contour = parse_polygon(raw.get("contour"))?;
        if contour.len() < 3 { anyhow::bail!("Part {entity_id} có contour không hợp lệ"); }
        let holes = raw.get("holes").and_then(Value::as_array).map(|items| {
            items.iter().filter_map(|item| parse_polygon(Some(item)).ok()).filter(|p| p.len() >= 3).collect()
        }).unwrap_or_default();
        let area = raw.get("area").and_then(Value::as_f64).unwrap_or_else(|| polygon_area(&contour).abs());
        let (min_x, min_y, max_x, max_y) = bounds(&contour);
        let width = raw.get("width").and_then(Value::as_f64).unwrap_or(max_x - min_x);
        let height = raw.get("height").and_then(Value::as_f64).unwrap_or(max_y - min_y);
        let base_rotation = raw.get("base_rotation_degrees").and_then(Value::as_f64).unwrap_or(0.0);
        let two_sided = raw.get("two_sided").and_then(Value::as_bool).unwrap_or(false);
        let special_shape = raw.get("special_shape").and_then(Value::as_bool).unwrap_or(false);
        Ok(Self { raw, entity_id, order, contour, holes, area, width, height, base_rotation, two_sided, special_shape })
    }
}

fn parse_polygon(value: Option<&Value>) -> anyhow::Result<Vec<Point>> {
    let rows = value.and_then(Value::as_array).ok_or_else(|| anyhow::anyhow!("Thiếu polygon"))?;
    let mut points = Vec::with_capacity(rows.len());
    for row in rows {
        let pair = row.as_array().ok_or_else(|| anyhow::anyhow!("Điểm polygon không hợp lệ"))?;
        if pair.len() < 2 { continue; }
        let x = pair[0].as_f64().ok_or_else(|| anyhow::anyhow!("Tọa độ X không hợp lệ"))?;
        let y = pair[1].as_f64().ok_or_else(|| anyhow::anyhow!("Tọa độ Y không hợp lệ"))?;
        if points.last().is_none_or(|last: &Point| (last[0]-x).abs() > 1e-8 || (last[1]-y).abs() > 1e-8) {
            points.push([x,y]);
        }
    }
    if points.len() > 2 && points.first() == points.last() { points.pop(); }
    Ok(points)
}

pub fn bounds(points: &[Point]) -> (f64,f64,f64,f64) {
    points.iter().fold((f64::INFINITY,f64::INFINITY,f64::NEG_INFINITY,f64::NEG_INFINITY), |b,p| {
        (b.0.min(p[0]), b.1.min(p[1]), b.2.max(p[0]), b.3.max(p[1]))
    })
}

pub fn polygon_area(points: &[Point]) -> f64 {
    if points.len() < 3 { return 0.0; }
    (0..points.len()).map(|i| {
        let a=points[i]; let b=points[(i+1)%points.len()]; a[0]*b[1]-b[0]*a[1]
    }).sum::<f64>()*0.5
}

#[derive(Debug, Clone, Serialize)]
pub struct SheetResult {
    pub index: usize,
    pub width: f64,
    pub height: f64,
    pub used_percent: f64,
    pub placements: Vec<Value>,
}

#[derive(Debug, Clone, Serialize)]
pub struct LayoutResult {
    pub key: String,
    pub material: String,
    pub thickness: f64,
    pub group_index: usize,
    pub part_count: usize,
    pub board_width: f64,
    pub board_height: f64,
    pub edge_margin: f64,
    pub cut_gap: f64,
    pub rotation_divisions: usize,
    pub sheet_in_sheet: bool,
    pub priority_zone_nesting: bool,
    pub optimize_flip_face: bool,
    pub compact_directions: Vec<String>,
    pub nesting_algorithm: String,
    pub packing_version: u32,
    pub target_sheet_utilization: f64,
    pub used_percent: f64,
    pub waste_percent: f64,
    pub waste_area: f64,
    pub compact_area: f64,
    pub sliver_score: f64,
    pub front_load_score: f64,
    pub two_sided_sheet_penalty: f64,
    pub first_sheet_used_percent: f64,
    pub elapsed_ms: u128,
    pub solver_strategy: String,
    pub selected_attempt: usize,
    pub sheets: Vec<SheetResult>,
}

#[derive(Debug, Serialize)]
pub struct EngineResult {
    pub ok: bool,
    pub source: String,
    pub layouts: Vec<LayoutResult>,
    pub optimization_attempts: usize,
    pub population_total: usize,
    pub engine: String,
    pub engine_version: String,
    pub cpu_workers: usize,
    pub message: String,
}

#[derive(Debug, Serialize)]
pub struct Progress<'a> {
    pub running: bool,
    pub phase: &'a str,
    pub stage: &'a str,
    pub overall_percent: f64,
    pub optimization_iteration: usize,
    pub optimization_total: usize,
    pub active_workers: usize,
    pub message: String,
}
