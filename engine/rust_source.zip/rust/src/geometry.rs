use crate::protocol::{bounds, Point};

#[derive(Debug, Clone)]
pub struct OrientedShape {
    pub rotation: f64,
    pub contour: Vec<Point>,
    pub holes: Vec<Vec<Point>>,
    pub width: f64,
    pub height: f64,
    pub min_x_before_normalize: f64,
    pub min_y_before_normalize: f64,
}

pub fn rotate_normalized(contour: &[Point], holes: &[Vec<Point>], degrees: f64) -> OrientedShape {
    let rad=degrees.to_radians(); let c=rad.cos(); let s=rad.sin();
    let rotate = |p: &Point| [p[0]*c-p[1]*s, p[0]*s+p[1]*c];
    let raw: Vec<Point> = contour.iter().map(rotate).collect();
    let (min_x,min_y,max_x,max_y)=bounds(&raw);
    let normalize = |p: Point| [round3(p[0]-min_x), round3(p[1]-min_y)];
    let contour=raw.into_iter().map(normalize).collect();
    let holes=holes.iter().map(|h| h.iter().map(rotate).map(normalize).collect()).collect();
    OrientedShape { rotation: normalize_rotation(degrees), contour, holes, width: round3(max_x-min_x), height: round3(max_y-min_y), min_x_before_normalize:min_x, min_y_before_normalize:min_y }
}

pub fn normalize_rotation(mut degrees:f64)->f64 { while degrees>180.0 {degrees-=360.0}; while degrees<=-180.0 {degrees+=360.0}; round3(degrees) }
pub fn round3(v:f64)->f64 {(v*1000.0).round()/1000.0}

pub fn polygon_intersects(a:&[Point], b:&[Point])->bool {
    if a.len()<3 || b.len()<3 {return false}
    for i in 0..a.len() { for j in 0..b.len() {
        if segments_intersect(a[i],a[(i+1)%a.len()],b[j],b[(j+1)%b.len()]) { return true; }
    }}
    point_in_polygon(a[0],b) || point_in_polygon(b[0],a)
}

pub fn translated(poly:&[Point],x:f64,y:f64)->Vec<Point>{ poly.iter().map(|p|[p[0]+x,p[1]+y]).collect() }

pub fn point_in_polygon(p:Point, poly:&[Point])->bool {
    let mut inside=false;
    let mut j=poly.len()-1;
    for i in 0..poly.len() {
        let pi=poly[i]; let pj=poly[j];
        let crossing=((pi[1]>p[1])!=(pj[1]>p[1])) && (p[0] < (pj[0]-pi[0])*(p[1]-pi[1])/((pj[1]-pi[1]).abs().max(1e-12))*if pj[1]>=pi[1]{1.0}else{-1.0}+pi[0]);
        if crossing {inside=!inside}; j=i;
    }
    inside
}

fn orient(a:Point,b:Point,c:Point)->f64 {(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])}
fn on_segment(a:Point,b:Point,p:Point)->bool { p[0]>=a[0].min(b[0])-1e-9&&p[0]<=a[0].max(b[0])+1e-9&&p[1]>=a[1].min(b[1])-1e-9&&p[1]<=a[1].max(b[1])+1e-9 }
fn segments_intersect(a:Point,b:Point,c:Point,d:Point)->bool {
    let o1=orient(a,b,c); let o2=orient(a,b,d); let o3=orient(c,d,a); let o4=orient(c,d,b);
    if ((o1>1e-9&&o2< -1e-9)||(o1< -1e-9&&o2>1e-9))&&((o3>1e-9&&o4< -1e-9)||(o3< -1e-9&&o4>1e-9)){return true}
    (o1.abs()<=1e-9&&on_segment(a,b,c))||(o2.abs()<=1e-9&&on_segment(a,b,d))||(o3.abs()<=1e-9&&on_segment(c,d,a))||(o4.abs()<=1e-9&&on_segment(c,d,b))
}

pub fn contact_length(a:(f64,f64,f64,f64), b:(f64,f64,f64,f64), gap:f64)->f64 {
    let mut total=0.0;
    if ((a.2+gap)-b.0).abs()<0.02 || ((b.2+gap)-a.0).abs()<0.02 { total+=(a.3.min(b.3)-a.1.max(b.1)).max(0.0); }
    if ((a.3+gap)-b.1).abs()<0.02 || ((b.3+gap)-a.1).abs()<0.02 { total+=(a.2.min(b.2)-a.0.max(b.0)).max(0.0); }
    total
}
