mod engine;
mod geometry;
mod protocol;

use crate::engine::{result_svg, solve_material, Runner};
use crate::protocol::{Cli, EngineResult, Job, Progress};
use anyhow::Context;
use std::fs;
use std::time::Instant;

fn main() {
    if let Err(error) = run() {
        eprintln!("{error:#}");
        std::process::exit(if error.to_string().contains("CANCELLED") { 130 } else { 1 });
    }
}

fn run() -> anyhow::Result<()> {
    let cli = Cli::parse()?;
    let started = Instant::now();
    let runner = Runner { cli: &cli, started };
    let job: Job = serde_json::from_slice(&fs::read(&cli.job).context("Không đọc được job.json")?)?;
    if job.protocol_version != 2 { anyhow::bail!("Protocol nesting không tương thích: {}", job.protocol_version); }
    let _ = rayon::ThreadPoolBuilder::new().num_threads(cli.workers).build_global();
    runner.progress(1.0, 0, job.materials.len().max(1), "Đã khởi động MN Jagua-Rust Engine 0.1.0.".into())?;
    let mut layouts = Vec::with_capacity(job.materials.len());
    for (index, material) in job.materials.iter().enumerate() {
        if runner.cancelled() { anyhow::bail!("CANCELLED"); }
        layouts.push(solve_material(&runner, material, index, job.materials.len())?);
        runner.write_json(&cli.preview, &serde_json::json!({"ok":true,"layouts":layouts}))?;
    }
    let sheet_count: usize = layouts.iter().map(|l| l.sheets.len()).sum();
    let part_count: usize = layouts.iter().map(|l| l.part_count).sum();
    let attempts: usize = layouts.iter().map(|l| l.selected_attempt.max(1)).sum();
    let result = EngineResult { ok:true, source:job.source, layouts, optimization_attempts:attempts, population_total:attempts, engine:"MN Jagua-Rust Engine".into(), engine_version:"0.1.0".into(), cpu_workers:cli.workers, message:format!("Đã hoàn tất nesting Rust cho {part_count} chi tiết trên {sheet_count} tấm phôi trong {:.2} giây.",started.elapsed().as_secs_f64()) };
    runner.write_json(&cli.result,&result)?;
    fs::write(&cli.svg,result_svg(&result))?;
    runner.write_json(&cli.progress,&Progress{running:false,phase:"optimizing",stage:"complete",overall_percent:100.0,optimization_iteration:attempts,optimization_total:attempts,active_workers:0,message:result.message.clone()})?;
    Ok(())
}
