use crate::geometry::{contact_length, rotate_normalized, round3, translated, OrientedShape};
use crate::protocol::*;
use anyhow::Context;
use jagua_rs::collision_detection::CDEConfig;
use jagua_rs::collision_detection::hazards::filter::NoFilter;
use jagua_rs::entities::{Item, Layout};
use jagua_rs::geometry::geo_traits::TransformableFrom;
use jagua_rs::geometry::DTransformation;
use jagua_rs::io::ext_repr::{ExtContainer, ExtItem, ExtShape, ExtSPolygon};
use jagua_rs::io::import::{ext_to_int_transformation, Importer};
use serde_json::{json, Value};
use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::Path;
use std::time::{Duration, Instant};

pub const PACKING_VERSION:u32=100;
const TARGET_UTILIZATION:f64=90.0;

#[derive(Clone)]
struct PreparedPart { part:Part, item:Item, orientations:Vec<OrientedShape> }
#[derive(Clone)]
struct Placed { part_index:usize, orientation_index:usize, x:f64, y:f64, internal_transform:DTransformation }
#[derive(Clone)]
struct Sheet { layout:Layout, placements:Vec<Placed> }
#[derive(Clone)]
struct Solution { sheets:Vec<Sheet>, strategy:String, attempt:usize }

#[derive(Clone, Copy, Debug, PartialEq)]
struct Score { sheets:usize, two_sided:f64, first_deficit:f64, compact:f64, sliver:f64, front_load:f64 }
impl Score { fn tuple(&self)->(usize,i64,i64,i64,i64,i64){(self.sheets,(self.two_sided*1000.0)as i64,(self.first_deficit*1000.0)as i64,(self.compact*1000.0)as i64,(self.sliver*1000.0)as i64,(self.front_load*1000.0)as i64)} }

pub struct Runner<'a> { pub cli:&'a Cli, pub started:Instant }
impl<'a> Runner<'a> {
 pub fn cancelled(&self)->bool { self.cli.cancel.exists() }
 pub fn write_json<T:serde::Serialize>(&self,path:&Path,value:&T)->anyhow::Result<()> {
   let temp=path.with_extension("tmp"); fs::write(&temp,serde_json::to_vec(value)?)?; fs::rename(temp,path)?; Ok(())
 }
 pub fn progress(&self,pct:f64,iteration:usize,total:usize,message:String)->anyhow::Result<()> {
   self.write_json(&self.cli.progress,&Progress{running:true,phase:"optimizing",stage:"rust_nesting",overall_percent:pct,optimization_iteration:iteration,optimization_total:total,active_workers:self.cli.workers,message})
 }
}

pub fn solve_material(runner:&Runner, state:&MaterialJob, material_index:usize, total_materials:usize)->anyhow::Result<LayoutResult> {
 let started=Instant::now(); let cfg=&state.configuration;
 validate_config(cfg)?;
 let parts:Vec<Part>=state.parts.clone().into_iter().map(Part::from_value).collect::<anyhow::Result<_>>()?;
 let importer=Importer::new(CDEConfig::default(),Some(0.0005),Some(cfg.cut_gap as f32),None);
 let container=importer.import_container(&ExtContainer{id:0,shape:ExtShape::Rectangle{x_min:cfg.edge_margin as f32,y_min:cfg.edge_margin as f32,width:(cfg.board_width-2.0*cfg.edge_margin) as f32,height:(cfg.board_height-2.0*cfg.edge_margin) as f32},zones:vec![]})?;
 let prepared:Vec<PreparedPart>=parts.into_iter().enumerate().map(|(id,part)|{
   let item=importer.import_item(&ExtItem{id:id as u64,allowed_orientations:Some(vec![0.0]),shape:ExtShape::SimplePolygon(ExtSPolygon(part.contour.iter().map(|p|(p[0] as f32,p[1] as f32)).collect())),min_quality:None})?;
   let orientations=allowed_rotations(&part,cfg.rotation_divisions).into_iter().map(|r|rotate_normalized(&part.contour,&part.holes,r)).collect();
   Ok(PreparedPart{part,item,orientations})
 }).collect::<anyhow::Result<_>>()?;
 let attempts=state_attempts(&prepared).max(4);
 let deadline=Instant::now()+Duration::from_millis(cfg.max_nesting_time_ms.clamp(10_000,180_000));
 let mut best:Option<Solution>=None;
 for attempt in 0..attempts {
   if runner.cancelled(){anyhow::bail!("CANCELLED")}
   if Instant::now()>=deadline && best.is_some(){break}
   let order=part_order(&prepared,attempt,cfg.optimize_flip_face);
   let mut candidate=construct_solution(&prepared,cfg,&container,&order,attempt,deadline,runner)?;
   front_load(&prepared,cfg,&container,&mut candidate,deadline,runner)?;
   compact_solution(&prepared,cfg,&container,&mut candidate,deadline,runner)?;
   if best.as_ref().is_none_or(|b| solution_score(&prepared,cfg,&candidate).tuple()<solution_score(&prepared,cfg,b).tuple()){best=Some(candidate)}
   let base=((material_index as f64)/(total_materials.max(1) as f64))*96.0;
   let span=96.0/(total_materials.max(1) as f64);
   runner.progress(base+span*((attempt+1) as f64/attempts as f64),(material_index*attempts)+attempt+1,total_materials*attempts,format!("Rust nesting: {} – phương án {}/{}",state.material,attempt+1,attempts))?;
 }
 let best=best.context("Không tạo được phương án nesting")?;
 build_result(state,&prepared,cfg,best,started.elapsed().as_millis())
}

fn validate_config(c:&Config)->anyhow::Result<()> { if c.board_width<=0.0||c.board_height<=0.0{anyhow::bail!("Khổ ván không hợp lệ")}; if c.edge_margin*2.0>=c.board_width||c.edge_margin*2.0>=c.board_height{anyhow::bail!("Hở viền lớn hơn vùng sử dụng")}; Ok(()) }
fn state_attempts(parts:&[PreparedPart])->usize { if parts.len()>400{4}else if parts.len()>150{6}else{8} }

fn allowed_rotations(part:&Part,divisions:usize)->Vec<f64>{
 let n=divisions.clamp(1,36); if n==1{return vec![part.base_rotation]};
 let cap=if !part.special_shape{4}else{12}; let selected=n.min(cap); let step=360.0/n as f64;
 let mut out=Vec::new(); for i in 0..selected {let source=if selected==n{i}else{(i*n)/selected};let r=part.base_rotation+step*source as f64;if !out.iter().any(|v:f64|((v-r)%360.0).abs()<1e-6){out.push(r)}} out
}

fn part_order(parts:&[PreparedPart],attempt:usize,optimize_flip:bool)->Vec<usize>{
 let mut ids:(Vec<usize>)=(0..parts.len()).collect();
 ids.sort_by(|&a,&b|{let pa=&parts[a].part;let pb=&parts[b].part; let fa=if optimize_flip&&pa.two_sided{0}else{1};let fb=if optimize_flip&&pb.two_sided{0}else{1};
 let aa=pa.area;let ab=pb.area;let la=pa.width.max(pa.height);let lb=pb.width.max(pb.height);let ea=aa/(pa.width*pa.height).max(1e-9);let eb=ab/(pb.width*pb.height).max(1e-9);
 let primary=match attempt%6 {0=>ab.total_cmp(&aa),1=>lb.total_cmp(&la),2=>ea.total_cmp(&eb),3=>pb.special_shape.cmp(&pa.special_shape),4=>(pb.holes.len()).cmp(&pa.holes.len()),_=>((hash_id(&pa.entity_id)^attempt as u64)).cmp(&(hash_id(&pb.entity_id)^attempt as u64))};
 fa.cmp(&fb).then(primary).then(pa.order.cmp(&pb.order))}); ids
}
fn hash_id(s:&str)->u64{s.bytes().fold(1469598103934665603,|h,b|(h^b as u64).wrapping_mul(1099511628211))}

fn construct_solution(parts:&[PreparedPart],cfg:&Config,container:&jagua_rs::entities::Container,order:&[usize],attempt:usize,deadline:Instant,runner:&Runner)->anyhow::Result<Solution>{
 let mut solution=Solution{sheets:vec![],strategy:format!("mn_rust_portfolio_{}",attempt%6),attempt};
 for (position,&part_index) in order.iter().enumerate(){
  if runner.cancelled(){anyhow::bail!("CANCELLED")}; if Instant::now()>=deadline&&position>0{ /* finish deterministically */ }
  let mut best:Option<(usize,usize,f64,f64,Vec<i64>,DTransformation)>=None;
  for sheet_index in 0..=solution.sheets.len(){
   if sheet_index==solution.sheets.len(){solution.sheets.push(Sheet{layout:Layout::new(container.clone()),placements:vec![]});}
   let candidates=candidate_positions(parts,cfg,&solution.sheets[sheet_index],part_index,attempt);
   for (orientation_index,x,y) in candidates{
    if let Some(internal)=feasible_transform(&solution.sheets[sheet_index],&parts[part_index],orientation_index,x,y){
     let rank=candidate_score(parts,cfg,&solution,sheet_index,part_index,orientation_index,x,y);
     if best.as_ref().is_none_or(|v|rank<&v.4){best=Some((sheet_index,orientation_index,x,y,rank,internal));}
    }
   }
   if solution.sheets[sheet_index].placements.is_empty()&&best.as_ref().is_some_and(|v|v.0<sheet_index){solution.sheets.pop();break;}
  }
  let (si,oi,x,y,_,internal)=best.ok_or_else(||anyhow::anyhow!("Chi tiết {} không vừa khổ ván",parts[part_index].part.entity_id))?;
  solution.sheets[si].layout.place_item(&parts[part_index].item,internal);
  solution.sheets[si].placements.push(Placed{part_index,orientation_index:oi,x,y,internal_transform:internal});
  while solution.sheets.last().is_some_and(|s|s.placements.is_empty()){solution.sheets.pop();}
 }
 Ok(solution)
}

fn candidate_positions(parts:&[PreparedPart],cfg:&Config,sheet:&Sheet,part_index:usize,attempt:usize)->Vec<(usize,f64,f64)>{
 let mut out=Vec::new(); let mut seen=HashSet::new(); let margin=cfg.edge_margin;let gap=cfg.cut_gap;
 for (oi,o) in parts[part_index].orientations.iter().enumerate(){
  let max_x=cfg.board_width-margin-o.width;let max_y=cfg.board_height-margin-o.height;if max_x<margin||max_y<margin{continue}
  let mut add=|x:f64,y:f64|{let x=x.clamp(margin,max_x);let y=y.clamp(margin,max_y);let k=(oi,(x*1000.0).round() as i64,(y*1000.0).round() as i64);if seen.insert(k){out.push((oi,round3(x),round3(y)))}};
  add(margin,margin);add(max_x,margin);add(margin,max_y);add(max_x,max_y);
  for fixed in &sheet.placements{let f=&parts[fixed.part_index].orientations[fixed.orientation_index];let fx=fixed.x;let fy=fixed.y;let fr=fx+f.width;let ft=fy+f.height;
   for x in [fx,fr+gap,fx-o.width-gap,fr-o.width] {for y in [fy,ft+gap,fy-o.height-gap,ft-o.height]{add(x,y)}}
   let fverts=sample_vertices(&f.contour,16);let mverts=sample_vertices(&o.contour,16);
   for fp in &fverts{for mp in &mverts{add(fx+fp[0]-mp[0]+if attempt%2==0{gap}else{0.0},fy+fp[1]-mp[1]+if attempt%3==0{gap}else{0.0})}}
  }
  if parts[part_index].part.special_shape || sheet.placements.len()<4 {let step=(o.width.min(o.height)/3.0).clamp(12.0,80.0);let mut y=margin;while y<=max_y&&out.len()<1600{let mut x=margin;while x<=max_x&&out.len()<1600{add(x,y);x+=step}y+=step}}
 }
 out
}
fn sample_vertices(poly:&[[f64;2]],limit:usize)->Vec<[f64;2]>{if poly.len()<=limit{return poly.to_vec()};(0..limit).map(|i|poly[i*poly.len()/limit]).collect()}

fn feasible_transform(sheet:&Sheet,part:&PreparedPart,oi:usize,x:f64,y:f64)->Option<DTransformation>{
 let o=&part.orientations[oi];
 // External transform maps original contour to the normalized rotated contour at x/y.
 let ext=DTransformation::new(o.rotation.to_radians() as f32,((x-o.min_x_before_normalize) as f32,(y-o.min_y_before_normalize) as f32));
 let internal=ext_to_int_transformation(&ext,&part.item.shape_orig.pre_transform);
 let transf=internal.compose(); let surrogate=part.item.shape_cd.surrogate();
 if sheet.layout.cde().detect_surrogate_collision(surrogate,&transf,&NoFilter){return None}
 let mut buffer=(*part.item.shape_cd).clone();buffer.surrogate=None;buffer.transform_from(&part.item.shape_cd,&transf);
 if sheet.layout.cde().detect_poly_collision(&buffer,&NoFilter){None}else{Some(internal)}
}

fn candidate_score(parts:&[PreparedPart],cfg:&Config,solution:&Solution,si:usize,pi:usize,oi:usize,x:f64,y:f64)->Vec<i64>{
 let sheet=&solution.sheets[si];let o=&parts[pi].orientations[oi];let right=x+o.width;let top=y+o.height;
 let (old_r,old_t)=sheet_extent(parts,sheet);let compact=((old_r.max(right)-cfg.edge_margin)*(old_t.max(top)-cfg.edge_margin)).max(0.0);
 let mut contact=0.0;for p in &sheet.placements{let f=&parts[p.part_index].orientations[p.orientation_index];contact+=contact_length((x,y,right,top),(p.x,p.y,p.x+f.width,p.y+f.height),cfg.cut_gap)}
 let sliver=local_sliver(cfg,sheet,parts,(x,y,right,top));let direction=direction_distance(cfg,x,y,right,top);
 let two=if parts[pi].part.two_sided{si as f64}else{0.0};let new_sheet=if sheet.placements.is_empty(){1}else{0};
 vec![new_sheet, (two*1000.0)as i64, (compact*1000.0)as i64,(sliver*1000.0)as i64,(-contact*1000.0)as i64,(direction*1000.0)as i64,si as i64]
}
fn direction_distance(cfg:&Config,x:f64,y:f64,r:f64,t:f64)->f64{let dirs=if cfg.compact_directions.is_empty(){vec!["left".to_string(),"bottom".to_string()]}else{cfg.compact_directions.clone()};dirs.iter().map(|d|match d.as_str(){"right"=>cfg.board_width-cfg.edge_margin-r,"top"=>cfg.board_height-cfg.edge_margin-t,"bottom"=>y-cfg.edge_margin,_=>x-cfg.edge_margin}).sum()}
fn local_sliver(cfg:&Config,sheet:&Sheet,parts:&[PreparedPart],b:(f64,f64,f64,f64))->f64{let threshold=cfg.cut_gap.max(8.0)*2.5;let mut p=0.0;for d in [b.0-cfg.edge_margin,b.1-cfg.edge_margin,cfg.board_width-cfg.edge_margin-b.2,cfg.board_height-cfg.edge_margin-b.3]{if d>0.001&&d<threshold{p+=threshold-d}}for q in &sheet.placements{let o=&parts[q.part_index].orientations[q.orientation_index];let qb=(q.x,q.y,q.x+o.width,q.y+o.height);for d in [(b.0-qb.2).abs(),(qb.0-b.2).abs(),(b.1-qb.3).abs(),(qb.1-b.3).abs()]{if d>cfg.cut_gap+0.001&&d<threshold{p+=(threshold-d)*0.5}}}p}

fn front_load(parts:&[PreparedPart],cfg:&Config,container:&jagua_rs::entities::Container,solution:&mut Solution,deadline:Instant,runner:&Runner)->anyhow::Result<()> {
 if solution.sheets.len()<2{return Ok(())};
 let mut changed=true;while changed&&Instant::now()<deadline{changed=false;
  for from in (1..solution.sheets.len()).rev(){let mut indices:Vec<usize>=(0..solution.sheets[from].placements.len()).collect();indices.sort_by_key(|&i|if parts[solution.sheets[from].placements[i].part_index].part.two_sided{0}else{1});
   for idx in indices{if idx>=solution.sheets[from].placements.len(){continue};if runner.cancelled(){anyhow::bail!("CANCELLED")};let moving=solution.sheets[from].placements[idx].clone();
    let mut target=None;for to in 0..from{for (oi,x,y) in candidate_positions(parts,cfg,&solution.sheets[to],moving.part_index,0){if let Some(t)=feasible_transform(&solution.sheets[to],&parts[moving.part_index],oi,x,y){target=Some((to,oi,x,y,t));break}}if target.is_some(){break}}
    if let Some((to,oi,x,y,t))=target{rebuild_without(parts,container,&mut solution.sheets[from],idx);solution.sheets[to].layout.place_item(&parts[moving.part_index].item,t);solution.sheets[to].placements.push(Placed{part_index:moving.part_index,orientation_index:oi,x,y,internal_transform:t});changed=true;break}
   } if changed{break}
  }
  solution.sheets.retain(|s|!s.placements.is_empty());
 }
 Ok(())
}
fn rebuild_without(parts:&[PreparedPart],container:&jagua_rs::entities::Container,sheet:&mut Sheet,index:usize){sheet.placements.remove(index);let placements=sheet.placements.clone();sheet.layout=Layout::new(container.clone());for p in &placements{sheet.layout.place_item(&parts[p.part_index].item,p.internal_transform);}sheet.placements=placements;}

fn compact_solution(parts:&[PreparedPart],cfg:&Config,container:&jagua_rs::entities::Container,solution:&mut Solution,deadline:Instant,runner:&Runner)->anyhow::Result<()> {
 for si in 0..solution.sheets.len(){if Instant::now()>=deadline{break};let mut pass=0;while pass<2{pass+=1;let mut moved=false;let count=solution.sheets[si].placements.len();for idx in 0..count{if runner.cancelled(){anyhow::bail!("CANCELLED")};if idx>=solution.sheets[si].placements.len(){continue};let old=solution.sheets[si].placements[idx].clone();let old_metric=direction_distance(cfg,old.x,old.y,old.x+parts[old.part_index].orientations[old.orientation_index].width,old.y+parts[old.part_index].orientations[old.orientation_index].height);let mut temp=solution.sheets[si].clone();rebuild_without(parts,container,&mut temp,idx);let mut best=None;for (oi,x,y) in candidate_positions(parts,cfg,&temp,old.part_index,0){if let Some(t)=feasible_transform(&temp,&parts[old.part_index],oi,x,y){let o=&parts[old.part_index].orientations[oi];let metric=direction_distance(cfg,x,y,x+o.width,y+o.height);if metric+0.01<old_metric&&best.as_ref().is_none_or(|b:&(f64,usize,f64,f64,DTransformation)|metric<b.0){best=Some((metric,oi,x,y,t))}}}if let Some((_,oi,x,y,t))=best{temp.layout.place_item(&parts[old.part_index].item,t);temp.placements.push(Placed{part_index:old.part_index,orientation_index:oi,x,y,internal_transform:t});solution.sheets[si]=temp;moved=true}}
 if !moved{break}}
 }
 Ok(())
}

fn sheet_extent(parts:&[PreparedPart],sheet:&Sheet)->(f64,f64){sheet.placements.iter().fold((0.0_f64,0.0_f64),|a,p|{let o=&parts[p.part_index].orientations[p.orientation_index];(a.0.max(p.x+o.width),a.1.max(p.y+o.height))})}
fn solution_score(parts:&[PreparedPart],cfg:&Config,s:&Solution)->Score{let usable=cfg.board_width*cfg.board_height;let mut two=0.0;let mut compact=0.0;let mut sliver=0.0;let mut front=0.0;let mut first_area=0.0;for (si,sh) in s.sheets.iter().enumerate(){let area=sh.placements.iter().map(|p|parts[p.part_index].part.area).sum::<f64>();if si==0{first_area=area};front+=area*(si as f64+1.0);for p in &sh.placements{if parts[p.part_index].part.two_sided{two+=si as f64*parts[p.part_index].part.area.max(1.0)}let o=&parts[p.part_index].orientations[p.orientation_index];sliver+=local_sliver(cfg,sh,parts,(p.x,p.y,p.x+o.width,p.y+o.height));}let (r,t)=sheet_extent(parts,sh);compact+=(r-cfg.edge_margin).max(0.0)*(t-cfg.edge_margin).max(0.0)}Score{sheets:s.sheets.len(),two,first_deficit:(TARGET_UTILIZATION-first_area/usable*100.0).max(0.0),compact,sliver,front_load:front}}

fn build_result(state:&MaterialJob,parts:&[PreparedPart],cfg:&Config,solution:Solution,elapsed:u128)->anyhow::Result<LayoutResult>{let score=solution_score(parts,cfg,&solution);let total_area=parts.iter().map(|p|p.part.area).sum::<f64>();let used=if solution.sheets.is_empty(){0.0}else{total_area/(solution.sheets.len() as f64*cfg.board_width*cfg.board_height)*100.0};let first=solution.sheets.first().map(|s|s.placements.iter().map(|p|parts[p.part_index].part.area).sum::<f64>()/(cfg.board_width*cfg.board_height)*100.0).unwrap_or(0.0);
 let sheets=solution.sheets.iter().enumerate().map(|(si,s)|{let area=s.placements.iter().map(|p|parts[p.part_index].part.area).sum::<f64>();let placements=s.placements.iter().map(|p|placement_value(&parts[p.part_index],&parts[p.part_index].orientations[p.orientation_index],p,si+1)).collect();SheetResult{index:si+1,width:round3(cfg.board_width),height:round3(cfg.board_height),used_percent:round3(area/(cfg.board_width*cfg.board_height)*100.0),placements}}).collect();
 Ok(LayoutResult{key:state.key.clone(),material:state.material.clone(),thickness:round3(state.thickness),group_index:state.group_index+1,part_count:state.original_part_count.max(parts.len()),board_width:round3(cfg.board_width),board_height:round3(cfg.board_height),edge_margin:round3(cfg.edge_margin),cut_gap:round3(cfg.cut_gap),rotation_divisions:cfg.rotation_divisions,sheet_in_sheet:cfg.sheet_in_sheet,priority_zone_nesting:cfg.priority_zone_nesting,optimize_flip_face:cfg.optimize_flip_face,compact_directions:cfg.compact_directions.clone(),nesting_algorithm:"MN Jagua-Rust Hybrid 0.1.0".into(),packing_version:PACKING_VERSION,target_sheet_utilization:TARGET_UTILIZATION,used_percent:round3(used),waste_percent:round3(100.0-used),waste_area:round3(solution.sheets.len() as f64*cfg.board_width*cfg.board_height-total_area),compact_area:round3(score.compact),sliver_score:round3(score.sliver),front_load_score:round3(score.front_load),two_sided_sheet_penalty:round3(score.two_sided),first_sheet_used_percent:round3(first),elapsed_ms:elapsed,solver_strategy:solution.strategy,selected_attempt:solution.attempt+1,sheets})}

fn placement_value(p:&PreparedPart,o:&OrientedShape,placed:&Placed,sheet_index:usize)->Value{let mut m=p.part.raw.clone();m.insert("contour".into(),json!(o.contour));m.insert("holes".into(),json!(o.holes));m.insert("packed_width".into(),json!(round3(o.width)));m.insert("packed_height".into(),json!(round3(o.height)));m.insert("rotation_degrees".into(),json!(round3(o.rotation)));m.insert("x".into(),json!(round3(placed.x)));m.insert("y".into(),json!(round3(placed.y)));m.insert("sheet_index".into(),json!(sheet_index));Value::Object(m)}

pub fn result_svg(result: &EngineResult) -> String {
    let mut y = 20.0_f64;
    let mut body = String::new();

    for layout in &result.layouts {
        for sheet in &layout.sheets {
            let x0 = 20.0_f64;
            body.push_str(&format!(
                "<rect x='{x0}' y='{y}' width='{}' height='{}' fill='none' stroke='#333'/>",
                sheet.width, sheet.height
            ));

            for placement in &sheet.placements {
                let x = placement.get("x").and_then(Value::as_f64).unwrap_or(0.0) + x0;
                let py = placement.get("y").and_then(Value::as_f64).unwrap_or(0.0) + y;

                if let Some(polygon) = placement.get("contour").and_then(Value::as_array) {
                    let points = polygon
                        .iter()
                        .filter_map(|value| {
                            let pair = value.as_array()?;
                            let px = pair.first()?.as_f64()?;
                            let point_y = pair.get(1)?.as_f64()?;
                            Some(format!("{},{}", x + px, py + point_y))
                        })
                        .collect::<Vec<_>>()
                        .join(" ");

                    body.push_str(&format!(
                        "<polygon points='{points}' fill='#ddd' stroke='#555'/>",
                    ));
                }
            }

            y += sheet.height + 20.0;
        }
    }

    format!(
        "<svg xmlns='http://www.w3.org/2000/svg' width='100%' height='{}' viewBox='0 0 4000 {}'>{}</svg>",
        y + 20.0,
        y + 20.0,
        body
    )
}
